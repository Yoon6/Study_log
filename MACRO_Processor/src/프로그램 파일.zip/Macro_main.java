import java.io.*;

/*
* 매크로 프로세서 설계
*
*
* 이중 패스 매크로를 설계하였다.
* 매크로 호출은 한번만 가능하다.
* 매크로 위치는 어디에 있어도 상관없다.
* 각 MNT, MDT, 형식인수표, 실인수표는 파일로 출력된다.
*
*
* Macro_main 클래스에서 입력 파일들을 배열로 바꿔 각 패스로 전달한다.
*
*
* Pass1 클래스에 input.txt 파일을 전달한다.
* MNT, MDT 테이블(.txt)과 형식 인수표(formal_arg_table.txt)를 만든다.
* 그리고 Pass1출력인 temp.txt를 만든다.
*
*
* 그 다음 Pass2 클래스에서 실인수표(actual_arg_table.txt)를 만들고,
* 최종 결과인 output.txt를 출력한다.
*
*
* 실행 방법
* 실행 전 temp.txt와 output.txt 모든 내용 삭제해야한다.
* Macro_main.java 소스코드를 실행해야한다.
*
* */

public class Macro_main {
    static String[] input1 = new String[100]; // 파일 입력 줄 단위로 받기, 100줄 까지만 한정했음
    static String[][] input2 = new String[100][]; // 파일 입력 줄 - 단어 단위로 받기

    public static void main(String[] args) {

        // Pass1에 배열로 변환된 input.txt 전달
        fileToArray(input1, input2, "input.txt");
        new Pass1(input1, input2);

        // 배열 초기화
        input1 = new String[100];
        input2 = new String[100][];

        // Pass2에 배열로 변환된 temp.txt(Pass1의 출력) 전달
        fileToArray(input1, input2, "temp.txt");
        new Pass2(input1, input2);

    }

    // 파일 입력을 배열로 바꿈
    public static void fileToArray(String[] str1, String[][] str2, String fileName){
        try{
            File file = new File("./src/"+fileName); // 해당 경로에서 파일을 읽어옴
            // 입력 스트림
            FileReader fileReader = new FileReader(file);
            // 입력 버퍼
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line ="";

            for(int i=0; (line=bufferedReader.readLine())!=null; i++){
                str1[i] = line; // 배열에 파일 한 줄 씩을 저장함
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        for(int i=0; str1[i]!=null; i++){
            str2[i] = str1[i].split("\\s+|,"); // 한줄에 있는 단어(명령어, 연산항) 별로 나누서 저장함
        }

    }
}

